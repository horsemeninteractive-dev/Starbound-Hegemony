// Procedural galaxy generator. Deterministic from a single seed.
// Targets bible-spec scale: ~40 sectors, ~400 systems, ~2000 bodies.

import {
  Body, BodyType, ContestState, EconomicStatus, Empire,
  Galaxy, Hyperlane, JumpGate, Sector, StarSystem, StarType,
} from "./types";
import { mulberry32, pick, randInt, weightedPick, sectorName, systemName, planetName, moonName, Rng } from "./rng";

const STAR_WEIGHTS: [StarType, number][] = [
  ["M", 38], ["K", 18], ["G", 12], ["F", 8], ["A", 5],
  ["B", 2], ["O", 0.6], ["whitedwarf", 5], ["neutron", 2],
  ["pulsar", 1.4], ["binary", 6], ["blackhole", 1],
];

const STAR_BASE_SIZE: Record<StarType, number> = {
  O: 5.2, B: 4.4, A: 3.6, F: 3.0, G: 2.6, K: 2.2, M: 1.8,
  whitedwarf: 1.0, neutron: 0.7, pulsar: 0.8, binary: 3.2, blackhole: 1.6,
};

const ECON_WEIGHTS: [EconomicStatus, number][] = [
  ["stable", 50], ["boom", 14], ["recession", 18], ["blockaded", 5], ["untapped", 13],
];

const EMPIRE_NAMES: { name: string; tag: string; hue: number }[] = [
  { name: "Hegemony Sovereign", tag: "HSO", hue: 185 },
  { name: "Vorlan Concordat", tag: "VLC", hue: 28 },
  { name: "Crimson Pact", tag: "CMP", hue: 358 },
  { name: "Ashen Directorate", tag: "ASD", hue: 280 },
  { name: "Mira League", tag: "MRL", hue: 145 },
  { name: "Sable Throne", tag: "SBT", hue: 320 },
  { name: "Korren Combine", tag: "KRC", hue: 50 },
  { name: "Free Drift Cooperative", tag: "FDC", hue: 200 },
];

function buildEmpires(): Empire[] {
  return EMPIRE_NAMES.map((e, i) => ({ id: `emp-${i}`, ...e }));
}

/** Place sectors as gaussian blobs in a disk; then drop systems inside each sector. */
function generateSectors(rng: Rng, count: number): Sector[] {
  const sectors: Sector[] = [];
  const galaxyRadius = 220; // larger overall disk for breathing room
  for (let i = 0; i < count; i++) {
    // Distribute sectors in a 2-arm spiral so the galaxy reads as a galaxy.
    const arm = i % 2 === 0 ? 0 : Math.PI;
    const t = i / count;
    const angle = arm + t * Math.PI * 4 + (rng() - 0.5) * 1.1;
    const r = 30 + t * galaxyRadius * 0.9 + (rng() - 0.5) * 28;
    const x = Math.cos(angle) * r;
    const z = Math.sin(angle) * r;
    const y = (rng() - 0.5) * 10;
    sectors.push({
      id: `sec-${i}`,
      name: sectorName(rng),
      hue: Math.floor(rng() * 360),
      centroid: [x, y, z],
      radius: 0,
      systemIds: [],
    });
  }
  return sectors;
}

function generateBodies(rng: Rng, systemId: string, starType: StarType): Body[] {
  const bodies: Body[] = [];

  // Black holes / neutrons / pulsars rarely have planets; usually asteroid debris.
  const exotic = starType === "blackhole" || starType === "neutron" || starType === "pulsar";
  const planetCount = exotic ? randInt(rng, 0, 2) : randInt(rng, 2, 7);

  let orbit = 6 + STAR_BASE_SIZE[starType] * 1.4;
  for (let i = 0; i < planetCount; i++) {
    orbit += randInt(rng, 3, 6);
    const isGas = rng() < (i > 2 ? 0.55 : 0.15);
    const type: BodyType = isGas ? "gas_giant" : "terrestrial";
    const id = `${systemId}-b${i}`;
    const name = planetName(rng, systemId.split("-")[1] ?? "X", i);
    const planet: Body = {
      id,
      systemId,
      name,
      type,
      orbit,
      phase: rng() * Math.PI * 2,
      size: isGas ? 1.6 + rng() * 1.4 : 0.6 + rng() * 0.7,
      hue: Math.floor(rng() * 360),
      ownerId: null,
      population: type === "terrestrial" ? Math.floor(rng() * 12000) / 10 : 0,
      resources: pickResources(rng, type),
      economy: weightedPick(rng, ECON_WEIGHTS),
    };
    bodies.push(planet);

    // Moons
    const moonCount = isGas ? randInt(rng, 0, 4) : randInt(rng, 0, 2);
    for (let m = 0; m < moonCount; m++) {
      bodies.push({
        id: `${id}-m${m}`,
        systemId,
        name: moonName(name, m),
        type: "moon",
        orbit: orbit + 1.4 + m * 0.6,
        phase: rng() * Math.PI * 2,
        size: 0.18 + rng() * 0.25,
        hue: 30 + Math.floor(rng() * 60),
        ownerId: null,
        population: 0,
        resources: ["Ore", "Silicates"],
        economy: "untapped",
      });
    }
  }

  // Asteroid belt(s)
  const beltCount = randInt(rng, 0, 2);
  for (let b = 0; b < beltCount; b++) {
    orbit += randInt(rng, 3, 5);
    const rocks = randInt(rng, 6, 14);
    for (let r = 0; r < rocks; r++) {
      bodies.push({
        id: `${systemId}-a${b}-${r}`,
        systemId,
        name: `${systemId.split("-")[1]}-Belt-${b + 1}-${r + 1}`,
        type: "asteroid",
        orbit: orbit + (rng() - 0.5) * 1.2,
        phase: rng() * Math.PI * 2,
        size: 0.12 + rng() * 0.18,
        hue: 30,
        ownerId: null,
        population: 0,
        resources: ["Ore"],
        economy: "untapped",
      });
    }
  }

  // Stations
  if (rng() < 0.45) {
    bodies.push({
      id: `${systemId}-stn`,
      systemId,
      name: `${systemId.split("-")[1]} Anchor`,
      type: "station",
      orbit: orbit + 4,
      phase: rng() * Math.PI * 2,
      size: 0.5,
      hue: 180,
      ownerId: null,
      population: Math.floor(rng() * 20) / 10,
      resources: ["Trade Hub"],
      economy: "stable",
    });
  }

  return bodies;
}

function pickResources(rng: Rng, type: BodyType): string[] {
  const pool = type === "gas_giant"
    ? ["Helium-3", "Energy Crystals", "Hydrogen"]
    : ["Ore", "Organics", "Rare Earths", "Silicates", "Water Ice"];
  const count = randInt(rng, 1, 3);
  const out: string[] = [];
  for (let i = 0; i < count; i++) {
    const p = pick(rng, pool);
    if (!out.includes(p)) out.push(p);
  }
  return out;
}

/** Scale-free hyperlane network: most systems 2-3 connections, hub systems 6-10. */
function generateHyperlanes(rng: Rng, systems: StarSystem[]): Hyperlane[] {
  const lanes: Hyperlane[] = [];
  const seen = new Set<string>();
  const key = (a: string, b: string) => (a < b ? `${a}|${b}` : `${b}|${a}`);

  const distance = (a: StarSystem, b: StarSystem) => {
    const dx = a.pos[0] - b.pos[0];
    const dy = a.pos[1] - b.pos[1];
    const dz = a.pos[2] - b.pos[2];
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  };

  // For each system, link to 2-3 nearest neighbours; chance of long-haul jump.
  for (const s of systems) {
    const sorted = systems
      .filter((o) => o.id !== s.id)
      .map((o) => [o, distance(s, o)] as const)
      .sort((a, b) => a[1] - b[1]);

    const localLinks = randInt(rng, 2, 3);
    for (let i = 0; i < localLinks && i < sorted.length; i++) {
      const target = sorted[i][0];
      const k = key(s.id, target.id);
      if (seen.has(k)) continue;
      seen.add(k);
      lanes.push({ id: `lane-${lanes.length}`, a: s.id, b: target.id });
    }

    // Hub systems (~5%) get extra long-range jumps.
    if (rng() < 0.05) {
      const extras = randInt(rng, 3, 7);
      for (let i = 0; i < extras; i++) {
        const target = sorted[randInt(rng, 4, Math.min(40, sorted.length - 1))][0];
        const k = key(s.id, target.id);
        if (seen.has(k)) continue;
        seen.add(k);
        lanes.push({ id: `lane-${lanes.length}`, a: s.id, b: target.id });
      }
    }
  }
  return lanes;
}

function attachJumpGates(systems: StarSystem[], lanes: Hyperlane[]) {
  const byId: Record<string, StarSystem> = Object.fromEntries(systems.map((s) => [s.id, s]));
  for (const lane of lanes) {
    const a = byId[lane.a];
    const b = byId[lane.b];
    a.gates.push({ id: `${lane.id}-g0`, systemId: a.id, targetSystemId: b.id, ownerId: null, toll: 0 });
    b.gates.push({ id: `${lane.id}-g1`, systemId: b.id, targetSystemId: a.id, ownerId: null, toll: 0 });
  }
}

function assignOwnership(rng: Rng, systems: StarSystem[], empires: Empire[]) {
  // Empires claim contiguous-ish blobs by picking seed systems then nearest neighbours.
  const remaining = new Set(systems.map((s) => s.id));
  for (const emp of empires) {
    const seed = pick(rng, [...remaining]);
    if (!seed) continue;
    const claimSize = randInt(rng, 18, 38);
    const queue = [seed];
    const claimed: string[] = [];
    while (queue.length && claimed.length < claimSize) {
      const id = queue.shift()!;
      if (!remaining.has(id)) continue;
      remaining.delete(id);
      claimed.push(id);
      const sys = systems.find((s) => s.id === id)!;
      // claim some bodies (not all → contestation possible)
      for (const body of sys.bodies) {
        if ((body.type === "terrestrial" || body.type === "gas_giant" || body.type === "station") && rng() < 0.7) {
          body.ownerId = emp.id;
        }
      }
      // expand to nearest unclaimed
      const neighbours = systems
        .filter((o) => remaining.has(o.id))
        .map((o) => {
          const d = Math.hypot(o.pos[0] - sys.pos[0], o.pos[2] - sys.pos[2]);
          return [o.id, d] as const;
        })
        .sort((a, b) => a[1] - b[1])
        .slice(0, 3);
      for (const [nid] of neighbours) queue.push(nid);
    }
  }
  // Compute contestation per system
  for (const sys of systems) {
    const owners = new Set<string>();
    for (const b of sys.bodies) if (b.ownerId) owners.add(b.ownerId);
    if (owners.size === 0) sys.contest = remaining.has(sys.id) ? "frontier" : "anarchic";
    else if (owners.size === 1) sys.contest = "controlled";
    else sys.contest = "contested";
  }
}

export function generateGalaxy(seed: number = 42, opts?: {
  sectors?: number;
  systemsPerSector?: [number, number];
}): Galaxy {
  const rng = mulberry32(seed);
  const sectorCount = opts?.sectors ?? 40;
  const range = opts?.systemsPerSector ?? [5, 15];

  const sectors = generateSectors(rng, sectorCount);
  const systems: StarSystem[] = [];

  for (const sector of sectors) {
    const sysCount = randInt(rng, range[0], range[1]);
    for (let i = 0; i < sysCount; i++) {
      // jitter near sector centroid — wider spread so stars don't clump
      const r = rng() * 18 + 3;
      const a = rng() * Math.PI * 2;
      const pos: [number, number, number] = [
        sector.centroid[0] + Math.cos(a) * r,
        sector.centroid[1] + (rng() - 0.5) * 4,
        sector.centroid[2] + Math.sin(a) * r,
      ];
      const starType = weightedPick(rng, STAR_WEIGHTS);
      const id = `sys-${systems.length}`;
      const sys: StarSystem = {
        id,
        sectorId: sector.id,
        name: systemName(rng),
        pos,
        starType,
        contest: "frontier",
        economy: weightedPick(rng, ECON_WEIGHTS),
        bodies: [],
        gates: [],
        sectorHue: sector.hue,
      };
      sys.bodies = generateBodies(rng, id, starType);
      sector.systemIds.push(id);
      systems.push(sys);
    }
  }

  // Compute each sector's bounding radius from its actual systems
  const systemById0 = Object.fromEntries(systems.map((s) => [s.id, s]));
  for (const sec of sectors) {
    let maxR = 0;
    for (const sid of sec.systemIds) {
      const s = systemById0[sid];
      const dx = s.pos[0] - sec.centroid[0];
      const dz = s.pos[2] - sec.centroid[2];
      const d = Math.hypot(dx, dz);
      if (d > maxR) maxR = d;
    }
    sec.radius = maxR + 4;
  }

  const hyperlanes = generateHyperlanes(rng, systems);
  attachJumpGates(systems, hyperlanes);

  const empires = buildEmpires();
  assignOwnership(rng, systems, empires);

  const systemById = Object.fromEntries(systems.map((s) => [s.id, s]));
  const sectorById = Object.fromEntries(sectors.map((s) => [s.id, s]));

  return { seed, sectors, systems, hyperlanes, empires, systemById, sectorById };
}
