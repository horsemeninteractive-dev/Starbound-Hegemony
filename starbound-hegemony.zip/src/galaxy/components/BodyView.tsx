// Body view — close-up of a planet/moon/asteroid/station.

import { useMemo, useRef, useEffect } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import * as THREE from "three";
import type { Body } from "@/galaxy/types";
import skyboxUrl from "@/assets/skybox.jpg";

function Skybox() {
  const { scene } = useThree();
  useEffect(() => {
    const loader = new THREE.TextureLoader();
    loader.load(skyboxUrl, (tex) => {
      tex.mapping = THREE.EquirectangularReflectionMapping;
      tex.colorSpace = THREE.SRGBColorSpace;
      scene.background = tex;
      scene.environment = tex;
    });
    return () => { scene.background = null; scene.environment = null; };
  }, [scene]);
  return null;
}

function CameraSetup({ key }: { key?: string }) {
  const { camera } = useThree();
  useEffect(() => {
    camera.position.set(0, 1.5, 6);
    camera.lookAt(0, 0, 0);
  }, [camera, key]);
  return null;
}

function Atmosphere({ radius, color }: { radius: number; color: THREE.Color }) {
  return (
    <mesh scale={1.06}>
      <sphereGeometry args={[radius, 64, 64]} />
      <meshBasicMaterial
        color={color}
        transparent
        opacity={0.35}
        side={THREE.BackSide}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </mesh>
  );
}

function PlanetSurface({ body }: { body: Body }) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((_, dt) => { if (ref.current) ref.current.rotation.y += dt * 0.08; });

  const color = useMemo(() => new THREE.Color().setHSL(body.hue / 360, 0.55, 0.45), [body.hue]);
  const ringColor = useMemo(() => new THREE.Color().setHSL(body.hue / 360, 0.4, 0.65), [body.hue]);
  const atmoColor = useMemo(() => new THREE.Color().setHSL((body.hue + 30) / 360, 0.6, 0.55), [body.hue]);

  if (body.type === "asteroid") {
    return (
      <mesh ref={ref}>
        <dodecahedronGeometry args={[1.6, 1]} />
        <meshStandardMaterial color={color} roughness={0.95} flatShading />
      </mesh>
    );
  }

  if (body.type === "station") {
    return (
      <group ref={ref as unknown as React.RefObject<THREE.Group>}>
        <mesh>
          <torusGeometry args={[1.8, 0.45, 24, 64]} />
          <meshStandardMaterial color="#7be9ff" emissive="#1eb5cc" emissiveIntensity={0.6} metalness={0.85} roughness={0.25} />
        </mesh>
        <mesh>
          <cylinderGeometry args={[0.4, 0.4, 3.0, 24]} />
          <meshStandardMaterial color="#3a4a5a" metalness={0.7} roughness={0.4} />
        </mesh>
        <mesh>
          <sphereGeometry args={[0.55, 32, 32]} />
          <meshStandardMaterial color="#9ef0ff" emissive="#1eb5cc" emissiveIntensity={0.5} />
        </mesh>
        <pointLight color="#7be9ff" intensity={1.2} distance={5} />
      </group>
    );
  }

  return (
    <group>
      <mesh ref={ref}>
        <sphereGeometry args={[1.8, 96, 96]} />
        <meshStandardMaterial color={color} roughness={0.85} metalness={0.05} />
      </mesh>
      {body.type === "terrestrial" && <Atmosphere radius={1.8} color={atmoColor} />}
      {body.type === "gas_giant" && (
        <>
          <Atmosphere radius={1.8} color={ringColor} />
          <mesh rotation={[Math.PI / 2.2, 0, 0]}>
            <ringGeometry args={[2.6, 3.6, 128]} />
            <meshBasicMaterial color={ringColor} transparent opacity={0.7} side={THREE.DoubleSide} depthWrite={false} />
          </mesh>
        </>
      )}
    </group>
  );
}

export function BodyView({ body }: { body: Body }) {
  return (
    <Canvas dpr={[1, 1.75]} gl={{ antialias: true }}>
      <CameraSetup key={body.id} />
      <Skybox />
      <ambientLight intensity={0.25} />
      <directionalLight position={[5, 4, 6]} intensity={2.2} color="#ffe3a8" />
      <directionalLight position={[-6, -2, -4]} intensity={0.4} color="#3da8ff" />
      <PlanetSurface body={body} />
      <OrbitControls enableDamping dampingFactor={0.1} minDistance={3.5} maxDistance={14} />
    </Canvas>
  );
}
