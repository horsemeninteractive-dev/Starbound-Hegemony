// System view — central star + orbiting bodies (planets, moons, asteroids, stations, gates).

import { useEffect, useMemo, useRef } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { OrbitControls, Html } from "@react-three/drei";
import * as THREE from "three";
import type { Body, StarSystem } from "@/galaxy/types";
import { StarVisual } from "./StarVisual";
import { STAR_META } from "@/galaxy/meta";
import skyboxUrl from "@/assets/skybox.jpg";

interface Props {
  system: StarSystem;
  onSelectBody: (id: string) => void;
}

function Skybox() {
  const { scene } = useThree();
  useEffect(() => {
    const loader = new THREE.TextureLoader();
    loader.load(skyboxUrl, (tex) => {
      tex.mapping = THREE.EquirectangularReflectionMapping;
      tex.colorSpace = THREE.SRGBColorSpace;
      scene.background = tex;
      scene.environment = tex;
    });
    return () => { scene.background = null; scene.environment = null; };
  }, [scene]);
  return null;
}

function CameraSetup({ key }: { key?: string }) {
  const { camera } = useThree();
  useEffect(() => {
    camera.position.set(0, 22, 38);
    camera.lookAt(0, 0, 0);
  }, [camera, key]);
  return null;
}

function OrbitRing({ radius }: { radius: number }) {
  const geom = useMemo(() => {
    const segments = 96;
    const positions = new Float32Array(segments * 3);
    for (let i = 0; i < segments; i++) {
      const t = (i / (segments - 1)) * Math.PI * 2;
      positions[i * 3] = Math.cos(t) * radius;
      positions[i * 3 + 1] = 0;
      positions[i * 3 + 2] = Math.sin(t) * radius;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    return g;
  }, [radius]);
  return (
    <line>
      <primitive object={geom} attach="geometry" />
      <lineBasicMaterial color="#2bd4e8" transparent opacity={0.18} depthWrite={false} />
    </line>
  );
}

function Atmosphere({ radius, color }: { radius: number; color: THREE.Color }) {
  // Inverted-faces backside glow for a fresnel-ish atmosphere look
  return (
    <mesh scale={1.08}>
      <sphereGeometry args={[radius, 48, 48]} />
      <meshBasicMaterial
        color={color}
        transparent
        opacity={0.28}
        side={THREE.BackSide}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </mesh>
  );
}

function BodyMesh({ body, onClick }: { body: Body; onClick: () => void }) {
  const ref = useRef<THREE.Group>(null);
  useFrame(({ clock }) => {
    if (!ref.current) return;
    const speed = 0.04 / Math.sqrt(body.orbit);
    const t = clock.getElapsedTime() * speed + body.phase;
    ref.current.position.set(Math.cos(t) * body.orbit, 0, Math.sin(t) * body.orbit);
  });

  const color = useMemo(() => new THREE.Color().setHSL(body.hue / 360, 0.55, 0.5), [body.hue]);
  const ringColor = useMemo(() => new THREE.Color().setHSL(body.hue / 360, 0.4, 0.65), [body.hue]);
  const atmoColor = useMemo(() => new THREE.Color().setHSL((body.hue + 30) / 360, 0.6, 0.55), [body.hue]);

  const isStation = body.type === "station";
  const isAsteroid = body.type === "asteroid";

  return (
    <group ref={ref}>
      <group
        onPointerOver={(e) => { e.stopPropagation(); document.body.style.cursor = "pointer"; }}
        onPointerOut={() => { document.body.style.cursor = "default"; }}
        onClick={(e) => { e.stopPropagation(); onClick(); }}
      >
        {isStation ? (
          <mesh>
            <torusGeometry args={[body.size, body.size * 0.25, 16, 32]} />
            <meshStandardMaterial color="#7be9ff" emissive="#1eb5cc" emissiveIntensity={0.6} metalness={0.7} roughness={0.3} />
          </mesh>
        ) : isAsteroid ? (
          <mesh>
            <dodecahedronGeometry args={[body.size, 0]} />
            <meshStandardMaterial color={color} roughness={0.95} flatShading />
          </mesh>
        ) : (
          <>
            <mesh>
              <sphereGeometry args={[body.size, 48, 48]} />
              <meshStandardMaterial color={color} roughness={0.8} metalness={0.05} />
            </mesh>
            {body.type === "terrestrial" && <Atmosphere radius={body.size} color={atmoColor} />}
            {body.type === "gas_giant" && <Atmosphere radius={body.size} color={ringColor} />}
          </>
        )}
        {body.type === "gas_giant" && (
          <mesh rotation={[Math.PI / 2.2, 0, 0]}>
            <ringGeometry args={[body.size * 1.4, body.size * 2.0, 64]} />
            <meshBasicMaterial color={ringColor} transparent opacity={0.55} side={THREE.DoubleSide} depthWrite={false} />
          </mesh>
        )}
      </group>
    </group>
  );
}

function JumpGateMarkers({ system, onSelect }: { system: StarSystem; onSelect: (id: string) => void }) {
  const outer = Math.max(...system.bodies.map((b) => b.orbit), 10) + 6;
  const ringRef = useRef<THREE.Group>(null);
  useFrame((_, dt) => { if (ringRef.current) ringRef.current.rotation.y += dt * 0.5; });
  return (
    <group>
      {system.gates.map((gate, i) => {
        const angle = (i / system.gates.length) * Math.PI * 2;
        const pos: [number, number, number] = [Math.cos(angle) * outer, 0, Math.sin(angle) * outer];
        return (
          <group key={gate.id} position={pos}>
            <group ref={ringRef as React.RefObject<THREE.Group>}>
              <mesh
                onClick={(e) => { e.stopPropagation(); onSelect(`gate:${gate.targetSystemId}`); }}
                onPointerOver={(e) => { e.stopPropagation(); document.body.style.cursor = "pointer"; }}
                onPointerOut={() => { document.body.style.cursor = "default"; }}
              >
                <torusGeometry args={[0.7, 0.12, 16, 32]} />
                <meshStandardMaterial color="#7be9ff" emissive="#7be9ff" emissiveIntensity={1.2} metalness={0.8} roughness={0.2} />
              </mesh>
            </group>
            <pointLight color="#7be9ff" intensity={0.6} distance={6} />
            <Html center distanceFactor={40} style={{ pointerEvents: "none" }}>
              <div className="font-mono-hud text-[9px] uppercase tracking-widest text-primary/80 whitespace-nowrap">
                ⬡ Jump Gate
              </div>
            </Html>
          </group>
        );
      })}
    </group>
  );
}

export function SystemView({ system, onSelectBody }: Props) {
  const meta = STAR_META[system.starType];
  return (
    <Canvas dpr={[1, 1.75]} gl={{ antialias: true }}>
      <CameraSetup key={system.id} />
      <Skybox />
      <ambientLight intensity={0.18} />
      {/* Star */}
      <StarVisual type={system.starType} scale={2.4} detailed />
      {/* Orbit rings + bodies */}
      {system.bodies.map((b) => (
        <group key={b.id}>
          {b.type !== "moon" && b.type !== "asteroid" && <OrbitRing radius={b.orbit} />}
          <BodyMesh body={b} onClick={() => onSelectBody(b.id)} />
        </group>
      ))}
      <JumpGateMarkers system={system} onSelect={onSelectBody} />
      <Html position={[0, -3.5, 0]} center distanceFactor={50} style={{ pointerEvents: "none" }}>
        <div className={`font-display text-[11px] uppercase tracking-[0.3em] ${meta.color} whitespace-nowrap text-glow`}>
          {meta.label} · {system.name}
        </div>
      </Html>
      <OrbitControls
        enableDamping
        dampingFactor={0.1}
        minDistance={8}
        maxDistance={120}
        maxPolarAngle={Math.PI / 1.8}
      />
    </Canvas>
  );
}
