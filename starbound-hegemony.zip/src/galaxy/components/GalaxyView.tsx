// Galaxy view — 3D top-down(ish) view of all sectors, systems, hyperlanes.
// Uses StarVisual per system so star types read correctly even at galaxy scale.

import { useMemo, useRef, useEffect } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { OrbitControls, Html } from "@react-three/drei";
import * as THREE from "three";
import type { Galaxy, StarSystem, Sector } from "@/galaxy/types";
import type { FilterState } from "@/galaxy/useGalaxyApp";
import { STAR_META } from "@/galaxy/meta";
import { StarVisual } from "./StarVisual";
import skyboxUrl from "@/assets/skybox.jpg";

interface Props {
  galaxy: Galaxy;
  matches: (s: StarSystem) => boolean;
  filters: FilterState;
  onSelectSystem: (id: string) => void;
  onHoverSystem: (id: string | null) => void;
  hoverSystemId: string | null;
}

/* ---------- Skybox ---------- */
function Skybox() {
  const { scene } = useThree();
  useEffect(() => {
    const loader = new THREE.TextureLoader();
    loader.load(skyboxUrl, (tex) => {
      tex.mapping = THREE.EquirectangularReflectionMapping;
      tex.colorSpace = THREE.SRGBColorSpace;
      scene.background = tex;
      scene.environment = tex;
    });
    return () => {
      scene.background = null;
      scene.environment = null;
    };
  }, [scene]);
  return null;
}

/* ---------- Hyperlanes ---------- */
function HyperlaneLines({ galaxy, matches }: { galaxy: Galaxy; matches: (s: StarSystem) => boolean }) {
  const positions = useMemo(() => {
    const arr: number[] = [];
    for (const lane of galaxy.hyperlanes) {
      const a = galaxy.systemById[lane.a];
      const b = galaxy.systemById[lane.b];
      if (!a || !b) continue;
      if (!matches(a) && !matches(b)) continue;
      arr.push(...a.pos, ...b.pos);
    }
    return new Float32Array(arr);
  }, [galaxy, matches]);

  const geom = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    return g;
  }, [positions]);

  return (
    <lineSegments geometry={geom}>
      <lineBasicMaterial color="#2bd4e8" transparent opacity={0.22} depthWrite={false} />
    </lineSegments>
  );
}

/* ---------- Sector borders (translucent disks on the galactic plane) ---------- */
function SectorBorders({ sectors }: { sectors: Sector[] }) {
  return (
    <group>
      {sectors.map((sec) => {
        const color = new THREE.Color().setHSL(sec.hue / 360, 0.6, 0.5);
        return (
          <group key={sec.id} position={[sec.centroid[0], 0, sec.centroid[2]]}>
            {/* Filled disk */}
            <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -1, 0]}>
              <circleGeometry args={[sec.radius, 48]} />
              <meshBasicMaterial color={color} transparent opacity={0.06} side={THREE.DoubleSide} depthWrite={false} />
            </mesh>
            {/* Outline ring */}
            <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.95, 0]}>
              <ringGeometry args={[sec.radius - 0.4, sec.radius, 64]} />
              <meshBasicMaterial color={color} transparent opacity={0.45} side={THREE.DoubleSide} depthWrite={false} />
            </mesh>
          </group>
        );
      })}
    </group>
  );
}

/* ---------- Per-system star renderer ---------- */
function GalaxyStar({
  system, visible, isHover, onSelect, onHover,
}: {
  system: StarSystem;
  visible: boolean;
  isHover: boolean;
  onSelect: (id: string) => void;
  onHover: (id: string | null) => void;
}) {
  const meta = STAR_META[system.starType];
  const color = `#${meta.hex}`;

  // Galaxy-scale visual size for the star type
  const scale = system.starType === "blackhole" ? 0.9
    : system.starType === "neutron" || system.starType === "pulsar" ? 0.7
    : system.starType === "binary" ? 0.85
    : system.starType === "O" || system.starType === "B" ? 0.95
    : system.starType === "whitedwarf" ? 0.55
    : 0.75;

  const hoverScale = isHover ? 1.7 : 1;
  const opacity = visible ? 1 : 0.18;

  return (
    <group position={system.pos}>
      {/* Invisible click/hover hitbox so neutron/pulsar/blackhole are still selectable */}
      <mesh
        onPointerOver={(e) => { e.stopPropagation(); onHover(system.id); document.body.style.cursor = "pointer"; }}
        onPointerOut={() => { onHover(null); document.body.style.cursor = "default"; }}
        onClick={(e) => { e.stopPropagation(); onSelect(system.id); }}
      >
        <sphereGeometry args={[1.6 * hoverScale, 8, 8]} />
        <meshBasicMaterial transparent opacity={0} depthWrite={false} />
      </mesh>

      <group scale={hoverScale}>
        <group visible={visible || opacity > 0}>
          <StarVisual type={system.starType} scale={scale} detailed={false} />
        </group>
      </group>

      {/* Soft visibility halo (also dims when filtered out) */}
      <mesh>
        <sphereGeometry args={[scale * (isHover ? 3.2 : 2.2), 12, 12]} />
        <meshBasicMaterial color={color} transparent opacity={visible ? 0.12 : 0.03} depthWrite={false} />
      </mesh>

      {isHover && (
        <Html distanceFactor={50} position={[0, scale * 2.5, 0]} center style={{ pointerEvents: "none" }}>
          <div className="font-mono-hud text-[10px] uppercase tracking-widest px-2 py-1 hud-panel text-primary whitespace-nowrap">
            {system.name} · {meta.label}
          </div>
        </Html>
      )}
    </group>
  );
}

function SystemPoints({ galaxy, matches, onSelect, onHover, hoverId }: {
  galaxy: Galaxy;
  matches: (s: StarSystem) => boolean;
  onSelect: (id: string) => void;
  onHover: (id: string | null) => void;
  hoverId: string | null;
}) {
  return (
    <group>
      {galaxy.systems.map((s) => (
        <GalaxyStar
          key={s.id}
          system={s}
          visible={matches(s)}
          isHover={hoverId === s.id}
          onSelect={onSelect}
          onHover={onHover}
        />
      ))}
    </group>
  );
}

function SectorLabels({ galaxy }: { galaxy: Galaxy }) {
  return (
    <group>
      {galaxy.sectors.map((sec) => (
        <Html key={sec.id} position={sec.centroid} center style={{ pointerEvents: "none" }} distanceFactor={180}>
          <div className="font-display text-[10px] uppercase tracking-[0.3em] text-primary/70 whitespace-nowrap text-glow">
            {sec.name}
          </div>
        </Html>
      ))}
    </group>
  );
}

function CameraSetup() {
  const { camera } = useThree();
  useEffect(() => {
    camera.position.set(0, 200, 240);
    camera.lookAt(0, 0, 0);
  }, [camera]);
  return null;
}

function NebulaBackdrop() {
  // Big translucent disk to give a galactic-disk impression.
  const ref = useRef<THREE.Mesh>(null);
  useFrame((_, dt) => { if (ref.current) ref.current.rotation.z += dt * 0.005; });
  return (
    <mesh ref={ref} rotation={[-Math.PI / 2, 0, 0]} position={[0, -3, 0]}>
      <ringGeometry args={[20, 260, 96]} />
      <meshBasicMaterial color="#0e9bb8" transparent opacity={0.05} side={THREE.DoubleSide} depthWrite={false} />
    </mesh>
  );
}

export function GalaxyView({ galaxy, matches, filters, onSelectSystem, onHoverSystem, hoverSystemId }: Props) {
  return (
    <Canvas dpr={[1, 1.75]} gl={{ antialias: true, powerPreference: "high-performance" }}>
      <fog attach="fog" args={["#02060d", 240, 580]} />
      <CameraSetup />
      <Skybox />
      <NebulaBackdrop />
      <ambientLight intensity={0.5} />
      {filters.layers.has("hyperlanes") && <HyperlaneLines galaxy={galaxy} matches={matches} />}
      {filters.layers.has("sectorBorders") && <SectorBorders sectors={galaxy.sectors} />}
      <SystemPoints
        galaxy={galaxy}
        matches={matches}
        onSelect={onSelectSystem}
        onHover={onHoverSystem}
        hoverId={hoverSystemId}
      />
      {filters.layers.has("sectorLabels") && <SectorLabels galaxy={galaxy} />}
      <OrbitControls
        enablePan
        enableRotate
        enableDamping
        dampingFactor={0.08}
        minDistance={40}
        maxDistance={480}
        maxPolarAngle={Math.PI / 2.05}
      />
    </Canvas>
  );
}
