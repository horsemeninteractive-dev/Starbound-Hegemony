// Shared 3D star renderer — produces realistic visuals per star type:
// supergiants/main-sequence: bright sphere + glow sprite
// neutron / pulsar: small sphere with twin polar jets + halo
// black hole: dark sphere with bright accretion ring + lensing halo
// binary: two offset stars
// white dwarf: tiny intense sphere

import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import type { StarType } from "@/galaxy/types";
import { STAR_META } from "@/galaxy/meta";

interface Props {
  type: StarType;
  /** Base scale multiplier. */
  scale?: number;
  /** Whether this star is in the foreground (system view) — adds extra detail. */
  detailed?: boolean;
}

export function StarVisual({ type, scale = 1, detailed = false }: Props) {
  const color = useMemo(() => new THREE.Color(`#${STAR_META[type].hex}`), [type]);

  switch (type) {
    case "blackhole":
      return <BlackHole scale={scale} detailed={detailed} />;
    case "neutron":
    case "pulsar":
      return <NeutronStar scale={scale} color={color} pulsar={type === "pulsar"} detailed={detailed} />;
    case "binary":
      return <BinaryStar scale={scale} detailed={detailed} />;
    case "whitedwarf":
      return <Sun scale={scale * 0.45} color={color} detailed={detailed} />;
    default:
      return <Sun scale={scale} color={color} detailed={detailed} />;
  }
}

/* ---------- Sun (main sequence + giants) ---------- */
function Sun({ scale, color, detailed }: { scale: number; color: THREE.Color; detailed: boolean }) {
  const ref = useRef<THREE.Mesh>(null);
  useFrame((_, dt) => {
    if (ref.current) ref.current.rotation.y += dt * 0.15;
  });
  return (
    <group>
      <mesh ref={ref}>
        <sphereGeometry args={[scale, detailed ? 48 : 16, detailed ? 48 : 16]} />
        <meshBasicMaterial color={color} toneMapped={false} />
      </mesh>
      <pointLight color={color} intensity={detailed ? 2.5 : 1} distance={detailed ? 80 : 30} />
      {/* Soft glow halo */}
      <mesh>
        <sphereGeometry args={[scale * 1.4, 24, 24]} />
        <meshBasicMaterial color={color} transparent opacity={0.18} depthWrite={false} />
      </mesh>
      {detailed && (
        <mesh>
          <sphereGeometry args={[scale * 2.2, 24, 24]} />
          <meshBasicMaterial color={color} transparent opacity={0.07} depthWrite={false} />
        </mesh>
      )}
    </group>
  );
}

/* ---------- Neutron / Pulsar ---------- */
function NeutronStar({ scale, color, pulsar, detailed }: { scale: number; color: THREE.Color; pulsar: boolean; detailed: boolean }) {
  const beam = useRef<THREE.Group>(null);
  useFrame((_, dt) => {
    if (beam.current) beam.current.rotation.y += dt * (pulsar ? 3.0 : 0.6);
  });
  const jetLen = scale * (detailed ? 12 : 5);
  const jetRad = scale * 0.25;
  return (
    <group>
      <mesh>
        <sphereGeometry args={[scale * 0.5, 24, 24]} />
        <meshBasicMaterial color={color} toneMapped={false} />
      </mesh>
      <mesh>
        <sphereGeometry args={[scale * 0.9, 16, 16]} />
        <meshBasicMaterial color={color} transparent opacity={0.25} depthWrite={false} />
      </mesh>
      <pointLight color={color} intensity={detailed ? 2 : 0.8} distance={40} />
      {/* Polar jets */}
      <group ref={beam}>
        <mesh position={[0, jetLen / 2, 0]}>
          <coneGeometry args={[jetRad, jetLen, 16, 1, true]} />
          <meshBasicMaterial color={color} transparent opacity={0.55} depthWrite={false} side={THREE.DoubleSide} />
        </mesh>
        <mesh position={[0, -jetLen / 2, 0]} rotation={[Math.PI, 0, 0]}>
          <coneGeometry args={[jetRad, jetLen, 16, 1, true]} />
          <meshBasicMaterial color={color} transparent opacity={0.55} depthWrite={false} side={THREE.DoubleSide} />
        </mesh>
      </group>
    </group>
  );
}

/* ---------- Binary ---------- */
function BinaryStar({ scale, detailed }: { scale: number; detailed: boolean }) {
  const ref = useRef<THREE.Group>(null);
  useFrame((_, dt) => {
    if (ref.current) ref.current.rotation.y += dt * 0.8;
  });
  const a = useMemo(() => new THREE.Color("#ffd24a"), []);
  const b = useMemo(() => new THREE.Color("#ff7a3d"), []);
  return (
    <group ref={ref}>
      <group position={[scale * 1.1, 0, 0]}>
        <Sun scale={scale * 0.7} color={a} detailed={detailed} />
      </group>
      <group position={[-scale * 1.1, 0, 0]}>
        <Sun scale={scale * 0.55} color={b} detailed={detailed} />
      </group>
    </group>
  );
}

/* ---------- Black Hole ---------- */
function BlackHole({ scale, detailed }: { scale: number; detailed: boolean }) {
  const ring = useRef<THREE.Mesh>(null);
  const halo = useRef<THREE.Mesh>(null);
  useFrame((_, dt) => {
    if (ring.current) ring.current.rotation.z += dt * 0.4;
    if (halo.current) halo.current.rotation.z -= dt * 0.1;
  });
  const accretion = useMemo(() => new THREE.Color("#ff8a3d"), []);
  const lens = useMemo(() => new THREE.Color("#7be9ff"), []);
  return (
    <group>
      {/* Singularity */}
      <mesh>
        <sphereGeometry args={[scale * 0.7, 32, 32]} />
        <meshBasicMaterial color="#000000" />
      </mesh>
      {/* Photon sphere / lensing halo */}
      <mesh ref={halo}>
        <ringGeometry args={[scale * 0.85, scale * 1.05, 64]} />
        <meshBasicMaterial color={lens} transparent opacity={0.65} side={THREE.DoubleSide} depthWrite={false} />
      </mesh>
      {/* Accretion disk */}
      <mesh ref={ring} rotation={[Math.PI / 2.4, 0, 0]}>
        <ringGeometry args={[scale * 1.2, scale * 2.8, 96]} />
        <meshBasicMaterial color={accretion} transparent opacity={0.85} side={THREE.DoubleSide} depthWrite={false} />
      </mesh>
      {detailed && (
        <mesh rotation={[Math.PI / 2.4, 0, 0]}>
          <ringGeometry args={[scale * 2.8, scale * 4.0, 96]} />
          <meshBasicMaterial color={accretion} transparent opacity={0.25} side={THREE.DoubleSide} depthWrite={false} />
        </mesh>
      )}
      <pointLight color={accretion} intensity={detailed ? 1.5 : 0.6} distance={40} />
    </group>
  );
}
