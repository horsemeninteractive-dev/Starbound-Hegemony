import logo from "@/assets/logo.png";
import { useState, useEffect, useRef } from "react";
import { Newspaper, Factory, Rocket, Users, User, Sparkles, Settings, X } from "lucide-react";

interface Props {
  view: "galaxy" | "system" | "body";
  systemName?: string;
  bodyName?: string;
  onBackToGalaxy: () => void;
  onBackToSystem: () => void;
}

const GAME_MENU = [
  { icon: Newspaper, label: "Articles", desc: "Galactic news feed" },
  { icon: Factory, label: "Factories", desc: "Production lines" },
  { icon: Rocket, label: "Fleets", desc: "Fleet command" },
  { icon: Users, label: "Party", desc: "Political party" },
  { icon: User, label: "Profile", desc: "Commander profile" },
  { icon: Sparkles, label: "Skill Tree", desc: "Doctrines & perks" },
  { icon: Settings, label: "Settings", desc: "Preferences" },
];

export function TopBar({ view, systemName, bodyName, onBackToGalaxy, onBackToSystem }: Props) {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close on outside click / escape
  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setMenuOpen(false);
    const onClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    window.addEventListener("keydown", onKey);
    window.addEventListener("mousedown", onClick);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("mousedown", onClick);
    };
  }, [menuOpen]);

  return (
    <header className="fixed top-0 inset-x-0 z-30 pointer-events-none">
      <div className="hud-panel hud-corner mx-2 mt-2 px-2 py-1.5 sm:px-3 sm:py-2 flex items-center gap-2 sm:gap-3 pointer-events-auto">
        {/* Logo — opens game-wide menu */}
        <button
          onClick={() => setMenuOpen((o) => !o)}
          aria-label="Open game menu"
          className="shrink-0 -m-1 p-1 rounded hover:bg-primary/10 transition relative"
        >
          <img
            src={logo}
            alt="Starbound Hegemony"
            className="h-12 sm:h-14 w-auto drop-shadow-[0_0_8px_hsl(var(--primary)/0.6)]"
          />
        </button>

        <div className="hidden sm:flex flex-col leading-none">
          <span className="font-display text-[12px] tracking-[0.3em] text-primary text-glow">STARBOUND</span>
          <span className="font-display text-[9px] tracking-[0.4em] text-muted-foreground">HEGEMONY · GALAXY CMD</span>
        </div>

        <div className="flex-1" />

        {/* Breadcrumb nav — visible on all viewports */}
        <nav className="flex font-mono-hud text-[9px] sm:text-[10px] uppercase tracking-widest items-center gap-0.5 sm:gap-1.5 overflow-x-auto max-w-[60%] sm:max-w-none">
          <button
            onClick={onBackToGalaxy}
            className={`px-1.5 sm:px-2 py-1 transition shrink-0 ${
              view === "galaxy" ? "text-primary text-glow" : "text-muted-foreground hover:text-primary"
            }`}
          >
            Galaxy
          </button>
          {systemName && (
            <>
              <span className="text-primary/40 shrink-0">›</span>
              <button
                onClick={onBackToSystem}
                className={`px-1.5 sm:px-2 py-1 transition truncate max-w-[80px] sm:max-w-[140px] ${
                  view === "system" ? "text-primary text-glow" : "text-muted-foreground hover:text-primary"
                }`}
              >
                {systemName}
              </button>
            </>
          )}
          {bodyName && (
            <>
              <span className="text-primary/40 shrink-0">›</span>
              <span className="px-1.5 sm:px-2 py-1 text-primary text-glow truncate max-w-[80px] sm:max-w-[140px]">
                {bodyName}
              </span>
            </>
          )}
        </nav>
      </div>

      {/* Game menu drawer */}
      {menuOpen && (
        <>
          <div className="fixed inset-0 bg-background/40 backdrop-blur-sm pointer-events-auto animate-fade-in" />
          <div
            ref={menuRef}
            className="hud-panel hud-corner fixed top-2 left-2 w-[min(320px,calc(100vw-1rem))] max-h-[calc(100vh-1rem)] overflow-y-auto pointer-events-auto animate-fade-in"
          >
            <div className="flex items-center justify-between px-3 py-2 border-b border-primary/20">
              <div className="flex items-center gap-2">
                <img src={logo} alt="" className="h-10 w-auto" />
                <div className="flex flex-col leading-none">
                  <span className="font-display text-[11px] tracking-[0.3em] text-primary text-glow">COMMAND</span>
                  <span className="font-mono-hud text-[8px] tracking-[0.3em] text-muted-foreground">HEGEMONY MENU</span>
                </div>
              </div>
              <button
                onClick={() => setMenuOpen(false)}
                aria-label="Close menu"
                className="text-muted-foreground hover:text-primary p-1"
              >
                <X size={16} />
              </button>
            </div>
            <nav className="p-2 flex flex-col gap-1">
              {GAME_MENU.map((item) => (
                <button
                  key={item.label}
                  onClick={() => setMenuOpen(false)}
                  className="flex items-center gap-3 px-3 py-2.5 text-left border-l-2 border-transparent hover:border-primary hover:bg-primary/5 transition group"
                >
                  <item.icon size={18} className="text-primary/70 group-hover:text-primary shrink-0" />
                  <div className="flex flex-col leading-tight min-w-0">
                    <span className="font-display text-[12px] uppercase tracking-[0.2em] text-foreground group-hover:text-primary truncate">
                      {item.label}
                    </span>
                    <span className="font-mono-hud text-[9px] uppercase tracking-wider text-muted-foreground truncate">
                      {item.desc}
                    </span>
                  </div>
                </button>
              ))}
            </nav>
          </div>
        </>
      )}
    </header>
  );
}
