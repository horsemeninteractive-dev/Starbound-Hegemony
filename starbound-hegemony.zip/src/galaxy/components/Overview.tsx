import type { Galaxy, StarSystem, Body } from "@/galaxy/types";
import { STAR_META, CONTEST_META, ECON_META, BODY_META } from "@/galaxy/meta";

/* ======================= GALAXY OVERVIEW ======================= */
export function GalaxyOverview({ galaxy }: { galaxy: Galaxy }) {
  const bodyCount = galaxy.systems.reduce((s, x) => s + x.bodies.length, 0);
  const contested = galaxy.systems.filter((s) => s.contest === "contested").length;
  const controlled = galaxy.systems.filter((s) => s.contest === "controlled").length;
  return (
    <Panel title="Galaxy Census" subtitle={`SEED · ${galaxy.seed}`}>
      <Row k="Sectors" v={galaxy.sectors.length} />
      <Row k="Star Systems" v={galaxy.systems.length} />
      <Row k="Celestial Bodies" v={bodyCount} />
      <Row k="Hyperlanes" v={galaxy.hyperlanes.length} />
      <Row k="Empires" v={galaxy.empires.length} />
      <Divider />
      <Row k="Controlled" v={controlled} accent="text-success" />
      <Row k="Contested" v={contested} accent="text-warning" />
      <Hint>Tap a star to enter its system.</Hint>
    </Panel>
  );
}

/* ======================= SYSTEM OVERVIEW ======================= */
export function SystemOverview({ system, galaxy, onSelectBody }: {
  system: StarSystem;
  galaxy: Galaxy;
  onSelectBody: (id: string) => void;
}) {
  const meta = STAR_META[system.starType];
  const sector = galaxy.sectorById[system.sectorId];
  const planets = system.bodies.filter((b) => b.type === "terrestrial" || b.type === "gas_giant");
  const moons = system.bodies.filter((b) => b.type === "moon").length;
  const asteroids = system.bodies.filter((b) => b.type === "asteroid").length;
  const stations = system.bodies.filter((b) => b.type === "station").length;

  const owners = new Map<string, number>();
  for (const b of system.bodies) {
    if (b.ownerId) owners.set(b.ownerId, (owners.get(b.ownerId) ?? 0) + 1);
  }

  return (
    <Panel title={system.name} subtitle={sector?.name ?? "Unknown Sector"}>
      <Row k="Star Class" v={meta.label} accent={meta.color} />
      <Row k="Description" v={meta.description} small />
      <Row k="Temperature" v={meta.temp} small />
      <Divider />
      <Row k="Status" v={CONTEST_META[system.contest].label} accent={CONTEST_META[system.contest].color} />
      <Row k="Economy" v={ECON_META[system.economy].label} accent={ECON_META[system.economy].color} />
      <Row k="Jump Gates" v={system.gates.length} />
      <Divider />
      <Row k="Planets" v={planets.length} />
      <Row k="Moons" v={moons} />
      <Row k="Asteroids" v={asteroids} />
      <Row k="Stations" v={stations} />
      {owners.size > 0 && (
        <>
          <Divider />
          <SubTitle>Holdings</SubTitle>
          {Array.from(owners.entries()).map(([id, n]) => {
            const emp = galaxy.empires.find((e) => e.id === id);
            if (!emp) return null;
            return (
              <Row
                key={id}
                k={emp.tag}
                v={`${n} body${n > 1 ? "ies" : "y"}`}
                dotColor={`hsl(${emp.hue} 70% 55%)`}
              />
            );
          })}
        </>
      )}

      <Divider />
      <SubTitle>Bodies (tap to view)</SubTitle>
      <div className="flex flex-col gap-1 max-h-[24vh] overflow-y-auto pr-1">
        {system.bodies
          .filter((b) => b.type !== "asteroid" || system.bodies.filter(x => x.type === "asteroid").indexOf(b) < 3)
          .slice(0, 20)
          .map((b) => (
            <button
              key={b.id}
              onClick={() => onSelectBody(b.id)}
              className="flex items-center justify-between gap-2 px-2 py-1 text-[10px] uppercase tracking-wider border border-border hover:border-primary/60 hover:bg-primary/5 text-left transition"
            >
              <span className="text-primary">{BODY_META[b.type].icon}</span>
              <span className="flex-1 truncate text-foreground">{b.name}</span>
              <span className="text-muted-foreground">{BODY_META[b.type].label}</span>
            </button>
          ))}
      </div>
    </Panel>
  );
}

/* ======================= BODY OVERVIEW ======================= */
export function BodyOverview({ body, galaxy }: { body: Body; galaxy: Galaxy }) {
  const owner = body.ownerId ? galaxy.empires.find((e) => e.id === body.ownerId) : null;
  return (
    <Panel title={body.name} subtitle={BODY_META[body.type].label}>
      <Row k="Type" v={BODY_META[body.type].label} />
      <Row k="Orbit" v={`${body.orbit.toFixed(1)} AU`} />
      <Row k="Size" v={`${(body.size * 6371).toFixed(0)} km radius`} />
      <Divider />
      <Row k="Population" v={body.population > 0 ? `${body.population.toFixed(1)} M` : "Uninhabited"} />
      <Row k="Economy" v={ECON_META[body.economy].label} accent={ECON_META[body.economy].color} />
      <Row
        k="Sovereign"
        v={owner?.name ?? "Unclaimed"}
        dotColor={owner ? `hsl(${owner.hue} 70% 55%)` : undefined}
      />
      <Divider />
      <SubTitle>Resources</SubTitle>
      <div className="flex flex-wrap gap-1.5">
        {body.resources.map((r) => (
          <span key={r} className="px-2 py-0.5 text-[10px] uppercase tracking-wider border border-primary/30 text-primary/90">
            {r}
          </span>
        ))}
      </div>
    </Panel>
  );
}

/* ======================= UI bits ======================= */
function Panel({ title, subtitle, children }: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <div className="hud-panel hud-corner p-3 w-full max-w-[320px] animate-fade-in pointer-events-auto">
      <div className="border-b border-primary/20 pb-2 mb-2">
        <div className="font-mono-hud text-[9px] uppercase tracking-[0.3em] text-primary/70">{subtitle ?? "—"}</div>
        <div className="font-display text-base uppercase tracking-[0.15em] text-primary text-glow truncate">
          {title}
        </div>
      </div>
      <div className="flex flex-col gap-1.5">{children}</div>
    </div>
  );
}

function Row({ k, v, accent, small, dotColor }: { k: string; v: React.ReactNode; accent?: string; small?: boolean; dotColor?: string }) {
  return (
    <div className="flex items-center justify-between gap-3 text-[11px]">
      <span className="font-mono-hud text-[9px] uppercase tracking-widest text-muted-foreground">{k}</span>
      <span className={`flex items-center gap-1.5 text-right ${small ? "text-[10px]" : ""} ${accent ?? "text-foreground"}`}>
        {dotColor && <span className="inline-block w-2 h-2 rounded-full" style={{ background: dotColor }} />}
        {v}
      </span>
    </div>
  );
}

function Divider() {
  return <div className="my-1.5 border-t border-primary/15" />;
}

function SubTitle({ children }: { children: React.ReactNode }) {
  return <div className="font-mono-hud text-[9px] uppercase tracking-[0.25em] text-primary/70 mt-1 mb-1">{children}</div>;
}

function Hint({ children }: { children: React.ReactNode }) {
  return <div className="mt-2 text-[10px] text-muted-foreground italic">{children}</div>;
}
