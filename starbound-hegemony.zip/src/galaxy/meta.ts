// Star type metadata for rendering and overview UI.

import type { StarType } from "./types";

export interface StarMeta {
  label: string;
  /** Full descriptive type name. */
  description: string;
  /** Tailwind class for color swatches/text. */
  color: string;
  /** Hex (without #) approximating the star's emission for THREE.Color. */
  hex: string;
  /** Approx temperature in K for the overview. */
  temp: string;
}

export const STAR_META: Record<StarType, StarMeta> = {
  O: { label: "O-class", description: "Blue supergiant", color: "text-star-o", hex: "9bb8ff", temp: "30,000 K+" },
  B: { label: "B-class", description: "Blue-white giant", color: "text-star-b", hex: "aac8ff", temp: "10,000–30,000 K" },
  A: { label: "A-class", description: "White main sequence", color: "text-star-a", hex: "cfeaff", temp: "7,500–10,000 K" },
  F: { label: "F-class", description: "Yellow-white", color: "text-star-f", hex: "ffefb8", temp: "6,000–7,500 K" },
  G: { label: "G-class", description: "Yellow main sequence", color: "text-star-g", hex: "ffd24a", temp: "5,200–6,000 K" },
  K: { label: "K-class", description: "Orange dwarf", color: "text-star-k", hex: "ff9442", temp: "3,700–5,200 K" },
  M: { label: "M-class", description: "Red dwarf", color: "text-star-m", hex: "ff5535", temp: "2,400–3,700 K" },
  whitedwarf: { label: "White Dwarf", description: "Dense stellar remnant", color: "text-star-a", hex: "e8f4ff", temp: "8,000–40,000 K" },
  neutron: { label: "Neutron Star", description: "Ultra-dense remnant with magnetic jets", color: "text-star-neutron", hex: "d6f7ff", temp: "600,000 K" },
  pulsar: { label: "Pulsar", description: "Rotating neutron star, beamed emission", color: "text-star-pulsar", hex: "8ff5ff", temp: "1,000,000 K" },
  binary: { label: "Binary System", description: "Two stars in mutual orbit", color: "text-star-binary", hex: "ffb066", temp: "varies" },
  blackhole: { label: "Black Hole", description: "Singularity with accretion disk", color: "text-star-blackhole", hex: "1a0033", temp: "—" },
};

export const CONTEST_META = {
  controlled: { label: "Controlled", color: "text-success", dot: "bg-success" },
  contested: { label: "Contested", color: "text-warning", dot: "bg-warning" },
  anarchic: { label: "Anarchic", color: "text-destructive", dot: "bg-destructive" },
  frontier: { label: "Frontier", color: "text-primary", dot: "bg-primary" },
} as const;

export const ECON_META = {
  boom: { label: "Boom", color: "text-success" },
  stable: { label: "Stable", color: "text-primary" },
  recession: { label: "Recession", color: "text-warning" },
  blockaded: { label: "Blockaded", color: "text-destructive" },
  untapped: { label: "Untapped", color: "text-muted-foreground" },
} as const;

export const BODY_META = {
  terrestrial: { label: "Terrestrial", icon: "◉" },
  gas_giant: { label: "Gas Giant", icon: "◎" },
  moon: { label: "Moon", icon: "○" },
  asteroid: { label: "Asteroid", icon: "◇" },
  station: { label: "Station", icon: "⬡" },
  jump_gate: { label: "Jump Gate", icon: "⬢" },
} as const;
