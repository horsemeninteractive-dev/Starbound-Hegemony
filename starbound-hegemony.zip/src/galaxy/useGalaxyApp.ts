// Central UI state for the map app. Galaxy data is generated once (deterministic).

import { useMemo, useState, useCallback } from "react";
import { generateGalaxy } from "./generate";
import type { Galaxy, StarSystem, Body, ContestState, EconomicStatus, StarType } from "./types";

export type ViewMode = "galaxy" | "system" | "body";
export type DisplayLayer = "hyperlanes" | "sectorBorders" | "sectorLabels";

export interface FilterState {
  contest: Set<ContestState>;
  economy: Set<EconomicStatus>;
  starType: Set<StarType>;
  layers: Set<DisplayLayer>;
}

const ALL_CONTEST: ContestState[] = ["controlled", "contested", "anarchic", "frontier"];
const ALL_ECON: EconomicStatus[] = ["boom", "stable", "recession", "blockaded", "untapped"];
const ALL_STAR: StarType[] = ["O", "B", "A", "F", "G", "K", "M", "whitedwarf", "neutron", "pulsar", "binary", "blackhole"];
const ALL_LAYERS: DisplayLayer[] = ["hyperlanes", "sectorLabels"];

export function useGalaxyApp(seed = 42) {
  const galaxy: Galaxy = useMemo(() => generateGalaxy(seed), [seed]);

  const [view, setView] = useState<ViewMode>("galaxy");
  const [systemId, setSystemId] = useState<string | null>(null);
  const [bodyId, setBodyId] = useState<string | null>(null);
  const [hoverSystemId, setHoverSystemId] = useState<string | null>(null);

  const [filters, setFilters] = useState<FilterState>({
    contest: new Set(ALL_CONTEST),
    economy: new Set(ALL_ECON),
    starType: new Set(ALL_STAR),
    layers: new Set(ALL_LAYERS),
  });

  const system: StarSystem | null = systemId ? galaxy.systemById[systemId] : null;
  const body: Body | null = useMemo(() => {
    if (!system || !bodyId) return null;
    return system.bodies.find((b) => b.id === bodyId) ?? null;
  }, [system, bodyId]);

  const openSystem = useCallback((id: string) => {
    setSystemId(id);
    setBodyId(null);
    setView("system");
  }, []);

  const openBody = useCallback((id: string) => {
    setBodyId(id);
    setView("body");
  }, []);

  const backToGalaxy = useCallback(() => {
    setView("galaxy");
    setSystemId(null);
    setBodyId(null);
  }, []);

  const backToSystem = useCallback(() => {
    setView("system");
    setBodyId(null);
  }, []);

  const toggleFilter = <K extends keyof FilterState>(kind: K, value: FilterState[K] extends Set<infer V> ? V : never) => {
    setFilters((prev) => {
      const next = new Set(prev[kind] as Set<unknown>);
      if (next.has(value)) next.delete(value);
      else next.add(value);
      return { ...prev, [kind]: next } as FilterState;
    });
  };

  const systemMatchesFilter = useCallback(
    (s: StarSystem) =>
      filters.contest.has(s.contest) &&
      filters.economy.has(s.economy) &&
      filters.starType.has(s.starType),
    [filters]
  );

  return {
    galaxy,
    view,
    system,
    body,
    hoverSystemId,
    setHoverSystemId,
    filters,
    toggleFilter,
    systemMatchesFilter,
    openSystem,
    openBody,
    backToGalaxy,
    backToSystem,
  };
}

export type GalaxyApp = ReturnType<typeof useGalaxyApp>;
