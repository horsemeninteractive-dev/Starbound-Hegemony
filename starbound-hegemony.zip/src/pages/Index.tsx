import { Suspense, useMemo, useState, useEffect } from "react";
import { ChevronUp, ChevronDown } from "lucide-react";
import { useGalaxyApp } from "@/galaxy/useGalaxyApp";
import { GalaxyView } from "@/galaxy/components/GalaxyView";
import { SystemView } from "@/galaxy/components/SystemView";
import { BodyView } from "@/galaxy/components/BodyView";
import { TopBar } from "@/galaxy/components/TopBar";
import { FilterPanel } from "@/galaxy/components/FilterPanel";
import { GalaxyOverview, SystemOverview, BodyOverview } from "@/galaxy/components/Overview";

const Index = () => {
  const app = useGalaxyApp(20260423);

  // If user clicks a "gate:<systemId>" pseudo-body, jump to that system instead.
  const handleSystemBodyClick = (id: string) => {
    if (id.startsWith("gate:")) {
      app.openSystem(id.slice(5));
      return;
    }
    app.openBody(id);
  };

  const matches = useMemo(() => app.systemMatchesFilter, [app.systemMatchesFilter]);

  return (
    <main className="relative h-screen w-screen overflow-hidden bg-background">
      {/* Subtle nebula vignette */}
      <div className="pointer-events-none absolute inset-0 bg-nebula opacity-60 z-0" />

      {/* 3D viewport */}
      <div className="absolute inset-0 z-10">
        <Suspense fallback={<LoadingHud />}>
          {app.view === "galaxy" && (
            <GalaxyView
              galaxy={app.galaxy}
              matches={matches}
              filters={app.filters}
              onSelectSystem={app.openSystem}
              onHoverSystem={app.setHoverSystemId}
              hoverSystemId={app.hoverSystemId}
            />
          )}
          {app.view === "system" && app.system && (
            <SystemView system={app.system} onSelectBody={handleSystemBodyClick} />
          )}
          {app.view === "body" && app.body && <BodyView body={app.body} />}
        </Suspense>
      </div>

      {/* Scanline overlay (very subtle) */}
      <div className="pointer-events-none absolute inset-0 z-20 scanline opacity-40" />

      {/* HUD */}
      <TopBar
        view={app.view}
        systemName={app.system?.name}
        bodyName={app.body?.name}
        onBackToGalaxy={app.backToGalaxy}
        onBackToSystem={app.backToSystem}
      />

      {/* Filters (galaxy view only) */}
      {app.view === "galaxy" && (
        <FilterPanel filters={app.filters} onToggle={app.toggleFilter} />
      )}

      {/* Overview panel — desktop: right side; mobile: bottom collapsible */}
      <div className="hidden sm:flex fixed right-2 top-16 bottom-2 z-30 flex-col items-end gap-2 pointer-events-none w-[min(340px,calc(100vw-1rem))]">
        <div className="pointer-events-auto w-full">
          {app.view === "galaxy" && <GalaxyOverview galaxy={app.galaxy} />}
          {app.view === "system" && app.system && (
            <SystemOverview system={app.system} galaxy={app.galaxy} onSelectBody={handleSystemBodyClick} />
          )}
          {app.view === "body" && app.body && <BodyOverview body={app.body} galaxy={app.galaxy} />}
        </div>
      </div>

      <MobileOverview app={app} onSelectBody={handleSystemBodyClick} />
    </main>
  );
};

function LoadingHud() {
  return (
    <div className="absolute inset-0 flex items-center justify-center">
      <div className="hud-panel hud-corner px-6 py-4 font-mono-hud text-[10px] uppercase tracking-[0.3em] text-primary text-glow">
        Initialising star chart...
      </div>
    </div>
  );
}

/* ===== Mobile bottom-anchored overview (compact + expandable) ===== */
function MobileOverview({
  app,
  onSelectBody,
}: {
  app: ReturnType<typeof useGalaxyApp>;
  onSelectBody: (id: string) => void;
}) {
  const [expanded, setExpanded] = useState(false);

  // Collapse when switching views to avoid stale expanded state
  useEffect(() => {
    setExpanded(false);
  }, [app.view, app.system?.id, app.body?.id]);

  // Compact summary line
  let title = "Galaxy";
  let subtitle = `${app.galaxy.systems.length} systems · ${app.galaxy.sectors.length} sectors`;
  if (app.view === "system" && app.system) {
    title = app.system.name;
    subtitle = `${app.system.bodies.length} bodies · ${app.system.starType.toUpperCase()}-class`;
  } else if (app.view === "body" && app.body) {
    title = app.body.name;
    subtitle =
      app.body.population > 0
        ? `${app.body.type.replace("_", " ")} · ${app.body.population.toFixed(1)}M pop`
        : `${app.body.type.replace("_", " ")} · uninhabited`;
  }

  return (
    <div className="sm:hidden fixed inset-x-2 bottom-2 z-30 pointer-events-auto">
      <div className="hud-panel hud-corner overflow-hidden flex flex-col">
        {/* Compact header bar */}
        <button
          onClick={() => setExpanded((e) => !e)}
          className="flex items-center gap-2 px-3 py-2 text-left hover:bg-primary/5 transition"
          aria-label={expanded ? "Collapse panel" : "Expand panel"}
        >
          <div className="flex-1 min-w-0">
            <div className="font-mono-hud text-[9px] uppercase tracking-[0.3em] text-primary/70 truncate">
              {subtitle}
            </div>
            <div className="font-display text-sm uppercase tracking-[0.15em] text-primary text-glow truncate">
              {title}
            </div>
          </div>
          <span className="shrink-0 text-primary border border-primary/40 rounded p-1">
            {expanded ? <ChevronDown size={16} /> : <ChevronUp size={16} />}
          </span>
        </button>

        {/* Expanded full overview */}
        {expanded && (
          <div className="border-t border-primary/20 max-h-[60vh] overflow-y-auto p-2 animate-fade-in">
            {app.view === "galaxy" && <GalaxyOverview galaxy={app.galaxy} />}
            {app.view === "system" && app.system && (
              <SystemOverview
                system={app.system}
                galaxy={app.galaxy}
                onSelectBody={onSelectBody}
              />
            )}
            {app.view === "body" && app.body && (
              <BodyOverview body={app.body} galaxy={app.galaxy} />
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default Index;
